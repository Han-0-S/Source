#!/usr/bin/env bash
#
# uninstall.sh - 자동 점검 서비스와 timesyncd drop-in 설정 제거
# (chrony.conf 는 .bak.<시각> 백업이 남아 있으므로 필요하면 수동으로 복원하세요)
set -u
(( EUID == 0 )) || { echo "root 권한(sudo)으로 실행하세요."; exit 1; }

systemctl disable --now ad-time-check.timer ad-time-check.service 2>/dev/null
rm -f /etc/systemd/system/ad-time-check.service /etc/systemd/system/ad-time-check.timer
rm -f /usr/local/sbin/ad-time-check
rm -f /etc/systemd/timesyncd.conf.d/10-ad-time.conf
systemctl daemon-reload
echo "제거 완료. /etc/default/ad-time-check 는 남겨 두었습니다 (필요 없으면 삭제)."
ls /etc/chrony/chrony.conf.bak.* 2>/dev/null && echo "↑ chrony 설정 백업 파일이 있습니다."
systemctl try-restart systemd-timesyncd 2>/dev/null
exit 0
