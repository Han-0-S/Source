#!/usr/bin/env bash
#
# install.sh - AD 시간 동기화 설정 + 부팅 시 자동 점검 서비스 설치
#
# 사용법 (root):
#   sudo ./install.sh --dc "dc01.corp.example.com dc02.corp.example.com" [옵션]
#
# 옵션:
#   --engine chrony|timesyncd|auto   사용할 시간 서비스 (기본 auto: chrony 가 설치되어 있으면 chrony)
#   --dc "<DC1> [DC2 ...]"           동기화/점검 대상 DC (필수, 공백 구분)
#   --fallback <서버>                chrony 에 추가할 보조 NTP 서버 (예: ntp.ubuntu.com)
#   --max-offset <초>                허용 시간차 (기본 60)
#   --install-deps                   필요한 패키지 설치 (chrony 선택 시 chrony, ldap-utils)
#   -h, --help                       도움말

set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd)
F=$HERE/files

ENGINE=auto; DC_LIST=""; FALLBACK=""; MAX_OFFSET=60; INSTALL_DEPS=0

usage() { sed -n '2,19p' "$0" | sed 's/^# \{0,1\}//'; }

while [[ $# -gt 0 ]]; do
  case $1 in
    --engine)       ENGINE=${2:?}; shift 2 ;;
    --dc)           DC_LIST=${2:?}; shift 2 ;;
    --fallback)     FALLBACK=${2:?}; shift 2 ;;
    --max-offset)   MAX_OFFSET=${2:?}; shift 2 ;;
    --install-deps) INSTALL_DEPS=1; shift ;;
    -h|--help)      usage; exit 0 ;;
    *) echo "알 수 없는 옵션: $1"; usage; exit 64 ;;
  esac
done

(( EUID == 0 )) || { echo "root 권한(sudo)으로 실행하세요."; exit 1; }
[[ -n $DC_LIST ]] || { echo "--dc 로 도메인 컨트롤러를 지정하세요."; usage; exit 64; }

if [[ $ENGINE == auto ]]; then
  if command -v chronyd >/dev/null 2>&1; then ENGINE=chrony; else ENGINE=timesyncd; fi
fi
[[ $ENGINE == chrony || $ENGINE == timesyncd ]] || { echo "--engine 은 chrony 또는 timesyncd"; exit 64; }
echo "==> 시간 서비스: $ENGINE / DC: $DC_LIST"

backup() {
  if [[ -e $1 ]]; then cp -a "$1" "$1.bak.$(date +%Y%m%d%H%M%S)"; fi
}

if (( INSTALL_DEPS )); then
  echo "==> 패키지 설치"
  apt-get update -qq
  pkgs="ldap-utils"
  [[ $ENGINE == chrony ]] && pkgs="$pkgs chrony"
  # shellcheck disable=SC2086
  apt-get install -y $pkgs
fi

install_timesyncd() {
  echo "==> systemd-timesyncd drop-in 설정"
  install -d /etc/systemd/timesyncd.conf.d
  backup /etc/systemd/timesyncd.conf.d/10-ad-time.conf
  sed -e "s|@DC_LIST@|$DC_LIST|" "$F/timesyncd-10-ad-time.conf" > /etc/systemd/timesyncd.conf.d/10-ad-time.conf
  systemctl unmask systemd-timesyncd 2>/dev/null || true
  systemctl enable systemd-timesyncd
  timedatectl set-ntp true
  systemctl restart systemd-timesyncd
}

install_chrony() {
  command -v chronyd >/dev/null 2>&1 || { echo "chrony 가 설치되어 있지 않습니다. --install-deps 를 사용하거나 'apt install chrony' 하세요."; exit 1; }
  echo "==> chrony 설정 (/etc/chrony/chrony.conf, 기존 파일은 .bak.<시각> 으로 백업)"
  local tmp; tmp=$(mktemp)
  for dc in $DC_LIST; do echo "server $dc iburst" >> "$tmp"; done
  if [[ -n $FALLBACK ]]; then echo "server $FALLBACK iburst" >> "$tmp"; fi
  install -d /etc/chrony
  backup /etc/chrony/chrony.conf
  sed -e "/@SERVERS@/{r $tmp" -e 'd}' "$F/chrony.conf" > /etc/chrony/chrony.conf
  rm -f "$tmp"
  # chrony 와 timesyncd 는 동시에 쓰지 않음
  systemctl disable --now systemd-timesyncd 2>/dev/null || true
  systemctl enable chrony
  systemctl restart chrony
}

if [[ $ENGINE == chrony ]]; then install_chrony; else install_timesyncd; fi

echo "==> 점검 스크립트 / 서비스 설치"
install -m 0755 "$F/ad-time-check" /usr/local/sbin/ad-time-check
if [[ -e /etc/default/ad-time-check ]]; then
  echo "    /etc/default/ad-time-check 가 이미 있어 유지합니다."
else
  sed -e "s|@DC_LIST@|$DC_LIST|" -e "s|@MAX_OFFSET@|$MAX_OFFSET|" "$F/ad-time-check.default" > /etc/default/ad-time-check
  chmod 0644 /etc/default/ad-time-check
fi
install -m 0644 "$F/ad-time-check.service" /etc/systemd/system/ad-time-check.service
install -m 0644 "$F/ad-time-check.timer"   /etc/systemd/system/ad-time-check.timer
systemctl daemon-reload
systemctl enable ad-time-check.service ad-time-check.timer
systemctl start ad-time-check.timer

echo "==> 지금 한 번 점검 실행"
systemctl start ad-time-check.service || true
echo
/usr/local/sbin/ad-time-check --status || true
echo
echo "완료. 로그 확인: journalctl -u ad-time-check -b --no-pager"
